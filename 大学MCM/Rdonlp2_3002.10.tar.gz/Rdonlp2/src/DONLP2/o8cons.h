/* **************************************************************************** */
/*                                  o8cons.h                                    */
/* **************************************************************************** */
static const double zero,one,two,three,four,
five,six,seven,
twom2,twop4,twop11,onep3,
onep5,p2,p4,p5,p7,p8,p9,
c45,tm12,
tm10,tm9,tm8,tm7,tm6,tm5,
tm4,tm3,tm2,tm1,tp1,tp2,
tp3,tp4;

